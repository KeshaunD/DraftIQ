const STORAGE_KEY_COLLAPSED = "draftCopilotCollapsed";
const toggleEl = document.getElementById("toggle");

function render(collapsed) {
  toggleEl.classList.toggle("on", !collapsed);
}

chrome.storage.local.get([STORAGE_KEY_COLLAPSED], (res) => {
  render(!!res[STORAGE_KEY_COLLAPSED]);
});

toggleEl.addEventListener("click", () => {
  chrome.storage.local.get([STORAGE_KEY_COLLAPSED], (res) => {
    const nextCollapsed = !res[STORAGE_KEY_COLLAPSED];
    chrome.storage.local.set({ [STORAGE_KEY_COLLAPSED]: nextCollapsed });
    render(nextCollapsed);
  });
});
