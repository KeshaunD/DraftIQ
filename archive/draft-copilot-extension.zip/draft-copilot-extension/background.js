chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    draftCopilotCollapsed: false,
    draftCopilotDrafted: [],
  });
});
