(function () {
  if (document.getElementById("draft-copilot-host")) return; // avoid double-inject

  const STORAGE_KEY_DRAFTED = "draftCopilotDrafted";
  const STORAGE_KEY_COLLAPSED = "draftCopilotCollapsed";

  const host = document.createElement("div");
  host.id = "draft-copilot-host";
  document.documentElement.appendChild(host);

  const shadow = host.attachShadow({ mode: "open" });

  const styleEl = document.createElement("style");
  styleEl.textContent = DRAFT_COPILOT_CSS;
  shadow.appendChild(styleEl);

  const root = document.createElement("div");
  root.className = "dc-root";
  root.innerHTML = `
    <div class="dc-tab" id="dc-tab">Draft Copilot</div>
    <div class="dc-dock">
      <div class="dc-rail" id="dc-rail"></div>
      <div class="dc-panel">
        <div class="dc-header">
          <div class="dc-wordmark">Draft<span>Copilot</span></div>
          <button class="dc-collapse-btn" id="dc-collapse" title="Collapse">&raquo;</button>
        </div>
        <div class="dc-controls">
          <input class="dc-search" id="dc-search" type="text" placeholder="Search players..." />
          <div class="dc-chips" id="dc-chips">
            ${["ALL", "WR", "RB", "QB", "TE"].map(p => `<div class="dc-chip${p === "ALL" ? " dc-chip-active" : ""}" data-pos="${p}">${p}</div>`).join("")}
          </div>
        </div>
        <div class="dc-list" id="dc-list"></div>
        <div class="dc-footer">Demo rankings &middot; click a player to mark drafted</div>
      </div>
    </div>
  `;
  shadow.appendChild(root);

  let activeFilter = "ALL";
  let searchTerm = "";
  let draftedIds = new Set();

  function playerId(p) {
    return p.name;
  }

  function loadState() {
    chrome.storage.local.get([STORAGE_KEY_DRAFTED, STORAGE_KEY_COLLAPSED], (res) => {
      if (res[STORAGE_KEY_DRAFTED]) draftedIds = new Set(res[STORAGE_KEY_DRAFTED]);
      if (res[STORAGE_KEY_COLLAPSED]) root.classList.add("dc-collapsed");
      renderList();
      renderRail();
    });
  }

  function saveDrafted() {
    chrome.storage.local.set({ [STORAGE_KEY_DRAFTED]: Array.from(draftedIds) });
  }

  function toggleDrafted(p) {
    const id = playerId(p);
    if (draftedIds.has(id)) draftedIds.delete(id);
    else draftedIds.add(id);
    saveDrafted();
    renderList();
    renderRail();
  }

  function filteredPlayers() {
    return DRAFT_COPILOT_PLAYERS.filter((p) => {
      const matchesPos = activeFilter === "ALL" || p.pos === activeFilter;
      const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesPos && matchesSearch;
    });
  }

  function renderList() {
    const listEl = shadow.getElementById("dc-list");
    const players = filteredPlayers();
    let html = "";
    let lastTier = null;
    players.forEach((p) => {
      if (p.tier !== lastTier) {
        html += `<div class="dc-tier-label">Tier ${p.tier}</div>`;
        lastTier = p.tier;
      }
      const isDrafted = draftedIds.has(playerId(p));
      const color = DRAFT_COPILOT_POSITION_COLORS[p.pos] || "#8CA0A6";
      html += `
        <div class="dc-card${isDrafted ? " dc-drafted" : ""}" style="border-left-color:${color}" data-id="${p.name}">
          <div class="dc-card-rank">${p.rank}</div>
          <div class="dc-card-main">
            <div class="dc-card-name">${p.name}</div>
            <div class="dc-card-meta"><span class="dc-pos" style="color:${color}">${p.pos}</span> &middot; ${p.team} &middot; BYE ${p.bye}</div>
            ${p.valueAlert ? `<div class="dc-value-tag">Value</div>` : ""}
          </div>
          <div class="dc-card-stats">
            <div class="dc-card-proj">${p.proj} pts</div>
            <div class="dc-card-adp">ADP ${p.adp}</div>
          </div>
        </div>
      `;
    });
    listEl.innerHTML = html || `<div class="dc-tier-label">No matches</div>`;

    listEl.querySelectorAll(".dc-card").forEach((card) => {
      card.addEventListener("click", () => {
        const id = card.getAttribute("data-id");
        const p = DRAFT_COPILOT_PLAYERS.find((pl) => pl.name === id);
        if (p) toggleDrafted(p);
      });
    });
  }

  function renderRail() {
    const railEl = shadow.getElementById("dc-rail");
    const players = DRAFT_COPILOT_PLAYERS;
    const maxRank = Math.max(...players.map((p) => p.rank));
    const tiers = Array.from(new Set(players.map((p) => p.tier))).sort((a, b) => a - b);

    let html = `<div class="dc-rail-line"></div>`;

    // tick marks at the first rank of each tier
    tiers.forEach((tier) => {
      const firstOfTier = players.find((p) => p.tier === tier);
      const pct = (firstOfTier.rank - 1) / (maxRank - 1);
      const top = 14 + pct * (100 - 4);
      html += `
        <div class="dc-rail-tick" style="top:${top}%"></div>
        <div class="dc-rail-tick-label" style="top:${top}%">T${tier}</div>
      `;
    });

    // a dot per player
    players.forEach((p) => {
      const pct = (p.rank - 1) / (maxRank - 1);
      const top = 14 + pct * (100 - 4);
      const color = DRAFT_COPILOT_POSITION_COLORS[p.pos] || "#8CA0A6";
      const isDrafted = draftedIds.has(playerId(p));
      html += `<div class="dc-rail-dot${isDrafted ? " dc-dot-drafted" : ""}" style="top:${top}%; background:${color}" title="${p.name}"></div>`;
    });

    railEl.innerHTML = html;
  }

  // controls
  shadow.getElementById("dc-search").addEventListener("input", (e) => {
    searchTerm = e.target.value;
    renderList();
  });

  shadow.getElementById("dc-chips").addEventListener("click", (e) => {
    const chip = e.target.closest(".dc-chip");
    if (!chip) return;
    activeFilter = chip.getAttribute("data-pos");
    shadow.querySelectorAll(".dc-chip").forEach((c) => c.classList.remove("dc-chip-active"));
    chip.classList.add("dc-chip-active");
    renderList();
  });

  function setCollapsed(collapsed) {
    root.classList.toggle("dc-collapsed", collapsed);
    chrome.storage.local.set({ [STORAGE_KEY_COLLAPSED]: collapsed });
  }

  shadow.getElementById("dc-collapse").addEventListener("click", () => setCollapsed(true));
  shadow.getElementById("dc-tab").addEventListener("click", () => setCollapsed(false));

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[STORAGE_KEY_COLLAPSED]) {
      root.classList.toggle("dc-collapsed", changes[STORAGE_KEY_COLLAPSED].newValue);
    }
  });

  loadState();
})();
