const DRAFT_COPILOT_CSS = `
@import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700&family=Inter:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap');

:host {
  all: initial;
}

* { box-sizing: border-box; }

.dc-root {
  position: fixed;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  font-family: 'Inter', system-ui, sans-serif;
  color: #EAF1F0;
  z-index: 2147483647;
  pointer-events: none;
}

.dc-dock,
.dc-tab {
  pointer-events: auto;
}

.dc-dock {
  position: fixed;
  top: 0;
  right: 0;
  width: 340px;
  max-width: 86vw;
  height: 100vh;
  background: #10151A;
  border-left: 1px solid #2B363C;
  display: flex;
  flex-direction: row;
  transform: translateX(0);
  transition: transform 180ms ease;
  box-shadow: -18px 0 40px rgba(0,0,0,0.35);
}

.dc-root.dc-collapsed .dc-dock {
  transform: translateX(100%);
}

.dc-tab {
  position: fixed;
  top: 50%;
  right: 0;
}

/* --- signature element: the value rail --- */
.dc-rail {
  width: 34px;
  flex-shrink: 0;
  background: #0D1216;
  border-right: 1px solid #2B363C;
  position: relative;
  padding: 14px 0;
}

.dc-rail-line {
  position: absolute;
  left: 50%;
  top: 14px;
  bottom: 14px;
  width: 1px;
  background: #2B363C;
  transform: translateX(-50%);
}

.dc-rail-tick {
  position: absolute;
  left: 50%;
  width: 12px;
  height: 1px;
  background: #3B474D;
  transform: translate(-50%, 0);
}

.dc-rail-tick-label {
  position: absolute;
  left: 50%;
  transform: translate(3px, -6px);
  font-family: 'IBM Plex Mono', monospace;
  font-size: 9px;
  color: #5E6E73;
  white-space: nowrap;
}

.dc-rail-dot {
  position: absolute;
  left: 50%;
  width: 7px;
  height: 7px;
  border-radius: 50%;
  transform: translate(-50%, -50%);
  box-shadow: 0 0 0 2px #10151A;
  transition: opacity 150ms ease, transform 150ms ease;
}

.dc-rail-dot.dc-dot-drafted {
  opacity: 0.25;
  transform: translate(-50%, -50%) scale(0.7);
}

/* --- panel --- */
.dc-panel {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.dc-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 14px 10px 14px;
  border-bottom: 1px solid #2B363C;
}

.dc-wordmark {
  font-family: 'Barlow Condensed', sans-serif;
  font-weight: 700;
  font-size: 17px;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: #EAF1F0;
}

.dc-wordmark span {
  color: #E8B94E;
}

.dc-collapse-btn {
  background: none;
  border: 1px solid #2B363C;
  color: #8CA0A6;
  width: 26px;
  height: 26px;
  border-radius: 6px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  line-height: 1;
}

.dc-collapse-btn:hover {
  border-color: #4FD1C5;
  color: #EAF1F0;
}

.dc-controls {
  padding: 10px 14px;
  border-bottom: 1px solid #2B363C;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.dc-search {
  width: 100%;
  background: #171F24;
  border: 1px solid #2B363C;
  border-radius: 7px;
  padding: 7px 10px;
  color: #EAF1F0;
  font-family: 'Inter', sans-serif;
  font-size: 12.5px;
  outline: none;
}

.dc-search::placeholder { color: #5E6E73; }
.dc-search:focus { border-color: #4FD1C5; }

.dc-chips {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
}

.dc-chip {
  font-family: 'IBM Plex Mono', monospace;
  font-size: 10.5px;
  letter-spacing: 0.03em;
  padding: 4px 9px;
  border-radius: 999px;
  border: 1px solid #2B363C;
  background: #171F24;
  color: #8CA0A6;
  cursor: pointer;
  text-transform: uppercase;
}

.dc-chip.dc-chip-active {
  color: #10151A;
  background: #EAF1F0;
  border-color: #EAF1F0;
}

.dc-list {
  flex: 1;
  overflow-y: auto;
  padding: 6px 10px 16px 10px;
}

.dc-tier-label {
  font-family: 'Barlow Condensed', sans-serif;
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.12em;
  color: #5E6E73;
  text-transform: uppercase;
  padding: 12px 4px 6px 4px;
}

.dc-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 8px;
  border-radius: 8px;
  border-left: 3px solid transparent;
  background: #141B20;
  margin-bottom: 5px;
  cursor: pointer;
  transition: background 120ms ease, opacity 120ms ease;
}

.dc-card:hover {
  background: #1B242A;
}

.dc-card.dc-drafted {
  opacity: 0.4;
}

.dc-card.dc-drafted .dc-card-name {
  text-decoration: line-through;
}

.dc-card-rank {
  font-family: 'IBM Plex Mono', monospace;
  font-size: 11px;
  color: #5E6E73;
  width: 18px;
  text-align: right;
  flex-shrink: 0;
}

.dc-card-main {
  flex: 1;
  min-width: 0;
}

.dc-card-name {
  font-family: 'Barlow Condensed', sans-serif;
  font-weight: 600;
  font-size: 15px;
  color: #EAF1F0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.dc-card-meta {
  font-size: 10.5px;
  color: #8CA0A6;
  margin-top: 1px;
}

.dc-card-meta .dc-pos {
  font-weight: 600;
}

.dc-card-stats {
  text-align: right;
  flex-shrink: 0;
  font-family: 'IBM Plex Mono', monospace;
}

.dc-card-proj {
  font-size: 12px;
  color: #EAF1F0;
}

.dc-card-adp {
  font-size: 9.5px;
  color: #5E6E73;
}

.dc-value-tag {
  display: inline-block;
  margin-top: 2px;
  font-family: 'IBM Plex Mono', monospace;
  font-size: 8.5px;
  letter-spacing: 0.05em;
  color: #10151A;
  background: #E8B94E;
  padding: 1px 5px;
  border-radius: 4px;
  text-transform: uppercase;
}

.dc-footer {
  padding: 8px 14px;
  border-top: 1px solid #2B363C;
  font-size: 10px;
  color: #4A575C;
}

/* --- collapsed tab handle --- */
.dc-tab {
  writing-mode: vertical-rl;
  transform: translateY(-50%) rotate(180deg);
  background: #171F24;
  border: 1px solid #2B363C;
  border-right: none;
  color: #8CA0A6;
  font-family: 'Barlow Condensed', sans-serif;
  font-weight: 600;
  font-size: 12px;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  padding: 14px 7px;
  border-radius: 8px 0 0 8px;
  cursor: pointer;
  display: none;
}

.dc-root.dc-collapsed .dc-tab {
  display: block;
}

.dc-tab:hover {
  color: #EAF1F0;
  border-color: #4FD1C5;
}

.dc-list::-webkit-scrollbar { width: 8px; }
.dc-list::-webkit-scrollbar-track { background: transparent; }
.dc-list::-webkit-scrollbar-thumb { background: #2B363C; border-radius: 4px; }

@media (prefers-reduced-motion: reduce) {
  .dc-dock { transition: none; }
}
`;
