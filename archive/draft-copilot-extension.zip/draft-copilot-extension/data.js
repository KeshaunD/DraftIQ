// Sample tiered rankings. In production this would be fetched from
// your rankings source (e.g. the master sheet / a hosted JSON feed).
// Shape kept intentionally simple so it's easy to swap the source later.
const DRAFT_COPILOT_PLAYERS = [
  { rank: 1, tier: 1, name: "Ja'Marr Chase", pos: "WR", team: "CIN", adp: 1.2, bye: 10, proj: 312 },
  { rank: 2, tier: 1, name: "Bijan Robinson", pos: "RB", team: "ATL", adp: 1.8, bye: 5, proj: 298 },
  { rank: 3, tier: 1, name: "Justin Jefferson", pos: "WR", team: "MIN", adp: 3.1, bye: 6, proj: 291 },
  { rank: 4, tier: 1, name: "Saquon Barkley", pos: "RB", team: "PHI", adp: 3.6, bye: 9, proj: 288 },
  { rank: 5, tier: 1, name: "CeeDee Lamb", pos: "WR", team: "DAL", adp: 4.4, bye: 10, proj: 279 },

  { rank: 6, tier: 2, name: "Jahmyr Gibbs", pos: "RB", team: "DET", adp: 5.9, bye: 8, proj: 271 },
  { rank: 7, tier: 2, name: "Amon-Ra St. Brown", pos: "WR", team: "DET", adp: 6.7, bye: 8, proj: 266 },
  { rank: 8, tier: 2, name: "Puka Nacua", pos: "WR", team: "LAR", adp: 7.3, bye: 6, proj: 261 },
  { rank: 9, tier: 2, name: "Josh Allen", pos: "QB", team: "BUF", adp: 8.5, bye: 12, proj: 259 },
  { rank: 10, tier: 2, name: "Malik Nabers", pos: "WR", team: "NYG", adp: 9.1, bye: 11, proj: 254 },

  { rank: 11, tier: 3, name: "Brian Thomas Jr.", pos: "WR", team: "JAX", adp: 11.4, bye: 8, proj: 244 },
  { rank: 12, tier: 3, name: "De'Von Achane", pos: "RB", team: "MIA", adp: 12.2, bye: 12, proj: 241 },
  { rank: 13, tier: 3, name: "Lamar Jackson", pos: "QB", team: "BAL", adp: 13.0, bye: 7, proj: 238 },
  { rank: 14, tier: 3, name: "Trey McBride", pos: "TE", team: "ARI", adp: 13.8, bye: 8, proj: 233 },
  { rank: 15, tier: 3, name: "Ashton Jeanty", pos: "RB", team: "LV", adp: 14.5, bye: 8, proj: 229 },

  { rank: 16, tier: 4, name: "Tetairoa McMillan", pos: "WR", team: "CAR", adp: 18.9, bye: 14, proj: 214, valueAlert: true },
  { rank: 17, tier: 4, name: "Kyren Williams", pos: "RB", team: "LAR", adp: 16.4, bye: 6, proj: 219 },
  { rank: 18, tier: 4, name: "George Kittle", pos: "TE", team: "SF", adp: 17.7, bye: 14, proj: 216 },
  { rank: 19, tier: 4, name: "Emeka Egbuka", pos: "WR", team: "TB", adp: 22.3, bye: 9, proj: 208, valueAlert: true },
  { rank: 20, tier: 4, name: "James Cook", pos: "RB", team: "BUF", adp: 19.6, bye: 12, proj: 211 },
];

const DRAFT_COPILOT_POSITION_COLORS = {
  WR: "#4FD1C5",
  RB: "#F0935A",
  QB: "#B98CE0",
  TE: "#7FC97F",
};
